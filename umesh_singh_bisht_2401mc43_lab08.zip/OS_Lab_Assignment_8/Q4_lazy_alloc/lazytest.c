// Q4 test: lazy heap allocation
#include "types.h"
#include "stat.h"
#include "user.h"
#include "meminfo.h"

#define MB (1024 * 1024)
#define SIZE (32 * MB)

void
pr(char *msg)
{
  struct meminfo mi;
  getmeminfo(&mi);
  printf(1, "%s: free=%d proc_pages=%d resident=%d pt_pages=%d\n",
         msg, mi.free_pages, mi.proc_pages, mi.rss_pages, mi.pt_pages);
}

int
freepages(void)
{
  struct meminfo mi;
  getmeminfo(&mi);
  return mi.free_pages;
}

int
main(int argc, char *argv[])
{
  char *p, *untouched;
  int start, fd[2], n, i, pid, ok;
  char buf[16];
  struct meminfo mi;
  int startpt;

  getmeminfo(&mi);
  start = mi.free_pages;
  startpt = mi.pt_pages;
  pr("start              ");

  // 1. big sbrk should not use any memory
  p = sbrk(SIZE);
  if(p == (char*)-1){
    printf(1, "sbrk failed\n");
    exit();
  }
  pr("after sbrk(32MB)   ");

  // 2. touch 4 pages far apart (each in a different 4MB region,
  //    so each also needs a new page table page)
  p[0] = 'A';
  p[8 * MB] = 'B';
  p[16 * MB] = 'C';
  p[SIZE - 1] = 'D';
  pr("after touching 4   ");
  printf(1, "values: %c %c %c %c\n", p[0], p[8*MB], p[16*MB], p[SIZE-1]);

  // 3. system calls with buffers in untouched pages
  untouched = p + 20 * MB;
  pipe(fd);
  write(fd[1], "hello lazy", 11);
  n = read(fd[0], untouched, 11);          // kernel writes into lazy page
  printf(1, "read() into untouched page: n=%d \"%s\"\n", n, untouched);
  n = write(fd[1], p + 24 * MB, 8);        // kernel reads from lazy page
  read(fd[0], buf, 8);
  ok = 1;
  for(i = 0; i < 8; i++)
    if(buf[i] != 0)
      ok = 0;
  printf(1, "write() from untouched page: n=%d, data all zero: %s\n",
         n, ok ? "yes" : "no");
  close(fd[0]);
  close(fd[1]);

  // 4. fork: copyuvm must skip the pages that are not present
  pid = fork();
  if(pid == 0){
    pr("child              ");
    printf(1, "child sees p[0]=%c p[16MB]=%c\n", p[0], p[16*MB]);
    p[30 * MB] = 'z';                       // fault in child only
    printf(1, "child touched another page ok\n");
    exit();
  }
  wait();
  pr("parent after wait  ");

  // 5. bad accesses must kill only the child
  printf(1, "\nchild will access address >= sz:\n");
  if(fork() == 0){
    char *bad = p + SIZE + 4096;
    *bad = 1;
    printf(1, "should not get here!\n");
    exit();
  }
  wait();

  printf(1, "child will access the stack guard page:\n");
  if(fork() == 0){
    char *guard = (char*)(((uint)&n & ~0xFFF) - 4096);
    *guard = 1;
    printf(1, "should not get here!\n");
    exit();
  }
  wait();
  printf(1, "parent still running, kernel is fine\n\n");

  // 6. give everything back.
  // deallocuvm() frees the frames but keeps the page table pages,
  // so those are counted separately here.
  sbrk(-SIZE);
  pr("after sbrk(-32MB)  ");
  getmeminfo(&mi);
  printf(1, "free at start %d, now %d, page table pages added %d\n",
         start, mi.free_pages, mi.pt_pages - startpt);
  if(start - mi.free_pages == mi.pt_pages - startpt)
    printf(1, "OK: every data frame was returned\n");
  else
    printf(1, "pages missing!\n");
  exit();
}
