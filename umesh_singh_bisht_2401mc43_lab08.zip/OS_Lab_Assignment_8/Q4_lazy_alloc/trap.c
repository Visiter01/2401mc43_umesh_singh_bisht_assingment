#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

// Q4: give a frame to the heap page containing va.
// returns 0 on success, -1 address not in heap (>= sz),
// -2 address below the heap (stack / guard page / code), -3 out of memory
int
lazyalloc(struct proc *p, uint va)
{
  char *mem;
  uint a;
  pte_t *pte;

  if(va >= p->sz)
    return -1;
  if(va < p->heapstart)
    return -2;
  a = PGROUNDDOWN(va);
  pte = walkpgdir(p->pgdir, (char*)a, 0);
  if(pte && (*pte & PTE_P))
    return -2;   // already mapped, so this was a protection fault
  if((mem = kalloc()) == 0)
    return -3;
  memset(mem, 0, PGSIZE);
  if(mappages(p->pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
    kfree(mem);   // could not get a page table page
    return -3;
  }
  return 0;
}

// Q4: make sure [va, va+n) is backed by frames. used by argptr()
// so read()/write() etc. never fault inside the kernel.
int
lazyrange(struct proc *p, uint va, uint n)
{
  uint a;
  pte_t *pte;

  for(a = PGROUNDDOWN(va); a < va + n; a += PGSIZE){
    pte = walkpgdir(p->pgdir, (char*)a, 0);
    if(pte && (*pte & PTE_P))
      continue;
    if(lazyalloc(p, a) < 0)
      return -1;
  }
  return 0;
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;

  case T_PGFLT: {
    uint va = rcr2();
    int r = -1;

    if(myproc())
      r = lazyalloc(myproc(), va);
    if(r == 0)
      break;   // page mapped, go back and retry the instruction
    if(myproc() == 0 || (tf->cs&3) == 0){
      // fault in kernel mode on a bad address, nothing we can do
      cprintf("page fault in kernel, va 0x%x eip 0x%x\n", va, tf->eip);
      panic("trap");
    }
    cprintf("pid %d %s: page fault at va 0x%x (eip 0x%x): %s -- killed\n",
            myproc()->pid, myproc()->name, va, tf->eip,
            r == -1 ? "address >= sz" :
            r == -2 ? "below heap / guard page" : "out of memory");
    myproc()->killed = 1;
    break;
  }

  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            myproc()->pid, myproc()->name, tf->trapno,
            tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}
