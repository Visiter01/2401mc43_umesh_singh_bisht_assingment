// Q2 test: physical memory statistics with getmeminfo()
#include "types.h"
#include "stat.h"
#include "user.h"
#include "meminfo.h"

#define NPAGES 20

void
pr(char *msg)
{
  struct meminfo mi;

  if(getmeminfo(&mi) < 0){
    printf(1, "getmeminfo failed\n");
    exit();
  }
  printf(1, "%s\n", msg);
  printf(1, "   total=%d free=%d proc_pages=%d pt_pages=%d resident=%d\n",
         mi.total_pages, mi.free_pages, mi.proc_pages, mi.pt_pages, mi.rss_pages);
}

int
freepages(void)
{
  struct meminfo mi;
  getmeminfo(&mi);
  return mi.free_pages;
}

int
main(int argc, char *argv[])
{
  char *p;
  int i, before, after, pid;

  pr("[1] at start");

  // grow the heap. sbrk is lazy (Q4) so nothing is allocated
  // until the pages are written, that's why we touch them
  p = sbrk(NPAGES * 4096);
  pr("[2] after sbrk(20 pages), not touched yet");
  for(i = 0; i < NPAGES; i++)
    p[i * 4096] = 1;
  pr("[3] after writing to all 20 pages");

  // fork: child gets a copy of every resident page + its own page tables
  before = freepages();
  pid = fork();
  if(pid == 0){
    pr("[4] inside child");
    exit();
  }
  wait();
  after = freepages();
  pr("[5] parent, after child exited and was reaped");

  printf(1, "\nfree pages before fork = %d, after wait = %d\n", before, after);
  if(before == after)
    printf(1, "OK: no memory leak\n");
  else
    printf(1, "LEAK: %d pages missing\n", before - after);

  sbrk(-NPAGES * 4096);
  pr("[6] after giving the 20 pages back with sbrk(-n)");
  exit();
}
