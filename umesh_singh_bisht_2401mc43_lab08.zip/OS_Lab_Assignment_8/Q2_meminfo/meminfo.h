// struct filled by getmeminfo() (Q2). Shared by kernel and user programs.
struct meminfo {
  int total_pages;   // physical pages handed to the allocator at boot
  int free_pages;    // pages currently on the free list
  int proc_pages;    // pages in this process's address space (sz / PGSIZE)
  int pt_pages;      // page directory + page table pages of this process
  int rss_pages;     // user pages that actually have a frame (differs from
                     // proc_pages once lazy allocation is on, see Q4)
};
