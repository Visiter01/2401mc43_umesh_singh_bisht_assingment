# OS Lab Assignment 8 – Memory Management in xv6

Name: umesh singh bisht  Roll No: 2401mc43


## Q1 – Virtual to physical address translation

**Design.** I made `walkpgdir()` in vm.c non-static and added it to defs.h so `sys_va2pa()` in sysproc.c can call it on `myproc()->pgdir` with `alloc = 0`. Before walking, the kernel prints the three parts of the address: `PDX(va)` (bits 31–22), `PTX(va)` (bits 21–12) and the offset (bits 11–0). If the PTE is missing, not present, or has no `PTE_U`, the call returns -1. Otherwise it returns `PTE_ADDR(*pte) | offset` and prints the P/W/U bits.

**Test (vatest).** The program prints mappings for a global, a local (stack) variable and a malloc block. `0x7FFFFFFF` returns -1 because nothing is mapped there, and `KERNBASE` returns -1 because it is mapped without `PTE_U`. After `fork()`, both parent and child print the same virtual address for the global. The physical addresses differ because `copyuvm()` copies each page into a new frame.


## Q2 – Physical memory statistics

**Design.** I added `nfree` and `ntotal` to the `kmem` struct in kalloc.c. `nfree` is updated in `kfree()` / `kalloc()` while `kmem.lock` is held. `ntotal` is set once, at the end of `kinit2()`. `struct meminfo` is in meminfo.h so both the kernel and user programs can include it. `pt_pages` counts the page directory plus every valid PDE. This includes the kernel half, because `setupkvm()` gives every process its own copy of those page tables, so even a small program uses about 60 pages for paging structures. I also added `rss_pages` (pages that really have a frame), because after Q4 `sz / PGSIZE` no longer shows real usage.


Free pages before the fork and after `wait()` are equal, so fork/exit/wait does not leak memory.

## Q3 – Dumping the page table

**Design.** `vmprint()` in vm.c loops over all 1024 PDEs. For each valid PDE below `PDX(KERNBASE)` it prints the PDE index, the physical address of the page table and its flags, then loops over the 1024 PTEs in that table. Each valid PTE is printed (indented) with its index, the virtual address `PGADDR(pdx, ptx, 0)`, the frame address and the flags. PDEs above KERNBASE are only counted. A PTE that is present but has no `PTE_U` is marked as the guard page.

**Observations (vmprinttest).**
- The first dump shows the code/data pages, then the guard page (`PW-`), then the stack page (`PWU`). `exec()` allocates these last two pages and calls `clearpteu()` on the lower one.
- After `sbrk(8*4096)` and writing to the new pages, 8 more PTEs show up after the stack.
- After `sbrk(-4096)` the last PTE is gone.
- In every dump, user pages = sz/PGSIZE − 1 (the guard page): ___ / ___ / ___.
- Kernel PDE count stays at ___ in all dumps.

## Q4 – Lazy allocation

**Design.**
- `sys_sbrk()`: for n > 0 it only increases `sz` (after checking it stays below KERNBASE). For n < 0 it still calls `growproc()`, because `deallocuvm()` already skips pages that were never mapped.
- I added `heapstart` to `struct proc`. It is set in `exec()` to the top of the user stack, and fork copies it. A fault is only treated as a lazy page if `heapstart <= va < sz`. This keeps the guard page, the stack and the code out of the lazy region.
- trap.c: in the new `T_PGFLT` case the handler reads `rcr2()` and calls `lazyalloc()`, which does `kalloc()`, zeroes the frame and calls `mappages()` with `PTE_W|PTE_U`. On failure it prints why and sets `killed`.
- When the kernel itself uses a lazy page, `argptr()` calls `lazyrange()` to map the whole buffer before the syscall uses it. If the kernel still faults on a valid heap address (for example in `fetchint()`), the trap handler maps the page and returns.
- `copyuvm()` skips PTEs that are not present instead of panicking. `uva2ka()` now checks for a null PTE.

`sbrk(32MB)` returns immediately and free pages do not change. Touching 4 pages uses 4 frames, plus one page table page for each new 4MB region touched. `read()` into an untouched buffer and `write()` from one both work. The two bad-access children are killed with a message, and the parent and kernel keep running.

## Problems faced

1. **`pte_t` unknown in defs.h.** `pte_t` was typedef'd in mmu.h, which most files include after defs.h, so the `walkpgdir()` prototype did not compile. Fixed by moving the typedef to types.h, next to `pde_t`.
2. **Q3 test showed no new entries after sbrk.** After Q4, sbrk does not map anything, so vmprint showed no change. The test now writes one byte to each new page before calling `vmprint()`. memtest does the same.
3. **fork panicked with "copyuvm: page not present"** once sbrk became lazy. Fixed by skipping missing PTEs in `copyuvm()`.
4. **System calls with a buffer in an untouched page.** The kernel would fault in kernel mode, which used to mean panic. Fixed by mapping the buffer in `argptr()`, with the trap handler as a fallback.
5. **Free pages not fully back after sbrk(-32MB) in lazytest.** The missing pages turned out to be page table pages. `deallocuvm()` never frees them (same as stock xv6), so the test checks that the difference equals the number of page table pages added.
6. **Newer gcc fails on stock xv6 with -Werror** (`-Warray-bounds`, `-Winfinite-recursion`). I added `-Wno-array-bounds -Wno-infinite-recursion` to CFLAGS.


