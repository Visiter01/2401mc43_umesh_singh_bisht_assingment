// Q3 test: dump the page table at different points
#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  char *p;
  int i;

  printf(1, "\n### 1) at start, sz = 0x%x\n", sbrk(0));
  vmprint();

  p = sbrk(8 * 4096);
  // sbrk is lazy after Q4, so write one byte per page to make
  // the new pages actually show up in the page table
  for(i = 0; i < 8; i++)
    p[i * 4096] = 'x';
  printf(1, "\n### 2) after sbrk(8*4096), sz = 0x%x\n", sbrk(0));
  vmprint();

  sbrk(-4096);
  printf(1, "\n### 3) after sbrk(-4096), sz = 0x%x\n", sbrk(0));
  vmprint();

  exit();
}
