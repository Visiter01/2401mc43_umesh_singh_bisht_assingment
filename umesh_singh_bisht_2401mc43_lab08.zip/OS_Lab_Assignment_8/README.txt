OS Lab Assignment 8 - Memory Management in xv6
------------------------------------------------

Folder layout

  xv6-public/      full xv6 source with all 4 questions done. build and run from here.
  Q1_va2pa/        files changed/added for Q1 + vatest.c
  Q2_meminfo/      files changed/added for Q2 + memtest.c
  Q3_vmprint/      files changed/added for Q3 + vmprinttest.c
  Q4_lazy_alloc/   files changed/added for Q4 + lazytest.c
  all_changes.diff diff against the original mit-pdos/xv6-public
  Report.md        report draft (fill in numbers from your own run)

Note: the files inside Q1..Q4 are the final versions, so a file like
sysproc.c or vm.c contains the changes of every question. Each change is
marked in a comment with the question number (Q1, Q2 ...).
Each Qx folder has a screenshots/ folder for that question's output.

Build and run (Linux / WSL / Ubuntu VM)

  sudo apt install build-essential gcc-multilib qemu-system-x86
  cd xv6-public
  make clean
  make qemu-nox

then inside xv6:

  $ vatest
  $ memtest
  $ vmprinttest
  $ lazytest

exit qemu with Ctrl-a then x.

The PDF only had Q1-Q4, so cowtest/protecttest/shmtest/pagerepl
(Q5-Q8 in the submission list) are not part of this.
