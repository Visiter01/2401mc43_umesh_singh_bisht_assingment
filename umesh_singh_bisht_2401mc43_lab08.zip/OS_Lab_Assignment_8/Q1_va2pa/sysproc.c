#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "meminfo.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(n > 0){
    // Q4: lazy allocation. only move sz, frames are given out
    // by the page fault handler in trap.c when a page is touched.
    if((uint)addr + n >= KERNBASE || (uint)addr + n < (uint)addr)
      return -1;
    myproc()->sz += n;
  } else if(n < 0){
    // shrinking still has to free whatever was really mapped,
    // deallocuvm() already skips pages that are not present
    if(growproc(n) < 0)
      return -1;
  }
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Q1: translate a user virtual address to a physical address
// using the current process page table. -1 if not mapped or not
// accessible from user mode.
int
sys_va2pa(void)
{
  int va;
  pte_t *pte;
  uint pa;

  if(argint(0, &va) < 0)
    return -1;

  cprintf("[kernel] va2pa(0x%x): pdx=%d ptx=%d offset=0x%x",
          va, PDX(va), PTX(va), va & 0xFFF);

  pte = walkpgdir(myproc()->pgdir, (void*)va, 0);
  if(pte == 0 || !(*pte & PTE_P)){
    cprintf(" -> not present\n");
    return -1;
  }
  cprintf(" flags P=%d W=%d U=%d", (*pte & PTE_P) != 0,
          (*pte & PTE_W) != 0, (*pte & PTE_U) != 0);
  if(!(*pte & PTE_U)){
    cprintf(" -> no user access\n");
    return -1;
  }
  pa = PTE_ADDR(*pte) | (va & 0xFFF);
  cprintf(" -> pa=0x%x\n", pa);
  return pa;
}

// Q2: fill struct meminfo for the calling process
int
sys_getmeminfo(void)
{
  struct meminfo *mi;
  struct proc *p = myproc();

  if(argptr(0, (char**)&mi, sizeof(*mi)) < 0)
    return -1;
  mi->total_pages = ktotalpages();
  mi->free_pages = kfreepages();
  mi->proc_pages = PGROUNDUP(p->sz) / PGSIZE;
  mi->pt_pages = ptpages(p->pgdir);
  mi->rss_pages = residentpages(p->pgdir, p->sz);
  return 0;
}

// Q3
int
sys_vmprint(void)
{
  vmprint(myproc()->pgdir, myproc()->sz);
  return 0;
}
