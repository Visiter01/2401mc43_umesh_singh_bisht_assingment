// Q1 test: virtual -> physical address translation using va2pa()
#include "types.h"
#include "stat.h"
#include "user.h"

int gvar = 100;   // global, lives in the data section

void
show(char *name, void *p)
{
  int pa = va2pa((int)p);
  if(pa == -1)
    printf(1, "%s: va 0x%x -> pa -1 (not mapped / no user access)\n", name, p);
  else
    printf(1, "%s: va 0x%x -> pa 0x%x\n", name, p, pa);
}

int
main(int argc, char *argv[])
{
  int local = 5;
  char *m;
  int pid, pa;

  printf(1, "\n== part c: some addresses of this process ==\n");
  m = malloc(64);
  m[0] = 'a';      // make sure the heap page is really used
  show("global ", &gvar);
  show("local  ", &local);
  show("malloc ", m);
  show("0x7FFFFFFF", (void*)0x7FFFFFFF);   // way above sz, should be -1
  show("KERNBASE", (void*)0x80000000);     // mapped, but PTE_U is clear

  printf(1, "\n== part d: fork, same va different pa ==\n");
  pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0){
    pa = va2pa((int)&gvar);
    printf(1, "child  (pid %d): &gvar = 0x%x, pa = 0x%x\n", getpid(), &gvar, pa);
    gvar = 999;   // only changes the child's copy
    exit();
  }
  wait();         // let child print first so output is not mixed up
  pa = va2pa((int)&gvar);
  printf(1, "parent (pid %d): &gvar = 0x%x, pa = 0x%x\n", getpid(), &gvar, pa);
  printf(1, "parent gvar is still %d (child wrote 999 to its own copy)\n", gvar);
  exit();
}
