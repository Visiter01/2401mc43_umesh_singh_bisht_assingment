#include "types.h"
#include "stat.h"
#include "user.h"

#define NUM_PROCS 4

void
cpu_work(int id, int init_prio)
{
  volatile int i, j;
  int pid = getpid();

  for(i = 0; i < 60; i++){
    for(j = 0; j < 2000000; j++){
      // Busy CPU-bound loop
    }
  }

  int final_prio = get_priority(pid);
  printf(1, ">>> [COMPLETED] Child %d (PID %d) | Initial Prio: %d | Final Prio: %d\n",
         id, pid, init_prio, final_prio);
  exit();
}

int
main(int argc, char *argv[])
{
  int priorities[NUM_PROCS] = {20, 14, 8, 4}; // Distinct priorities including 20 (lowest)
  int i, pid;

  printf(1, "--- Starting Priority Scheduler + Aging Test ---\n");
  // Boost parent priority to 1 so it forks all 4 children before they preempt it
  set_priority(getpid(), 1);

  for(i = 0; i < NUM_PROCS; i++){
    pid = fork();
    if(pid == 0){
      int mypid = getpid();
      set_priority(mypid, priorities[i]);
      printf(1, "[Spawned] Child %d (PID %d) assigned Priority %d\n",
             i + 1, mypid, get_priority(mypid));
      cpu_work(i + 1, priorities[i]);
    }
  }

  for(i = 0; i < NUM_PROCS; i++){
    wait();
  }

  printf(1, "--- All processes finished without starvation! ---\n");
  exit();
}
