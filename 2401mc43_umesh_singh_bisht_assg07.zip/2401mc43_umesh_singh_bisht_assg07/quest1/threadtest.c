#include "types.h"
#include "stat.h"
#include "user.h"

int shared_counter = 0;

void worker(void *arg) {
    int i;
    for(i = 0; i < 100000; i++) {
        shared_counter++; // No locks yet, so this will cause race conditions
    }
    exit();
}

int main(int argc, char *argv[]) {
    // Allocate 4096-byte stacks for the 3 threads
    void *stack1 = malloc(4096);
    void *stack2 = malloc(4096);
    void *stack3 = malloc(4096);

    printf(1, "Starting thread test...\n");

    // Spawn the threads
    clone(worker, 0, stack1);
    clone(worker, 0, stack2);
    clone(worker, 0, stack3);

    // Wait for all 3 threads to finish[cite: 11]
    join();
    join();
    join();

    // Print the final result[cite: 11]
    printf(1, "Final counter value: %d (Expected around 300,000 without sync)\n", shared_counter);
    
    exit();
}
