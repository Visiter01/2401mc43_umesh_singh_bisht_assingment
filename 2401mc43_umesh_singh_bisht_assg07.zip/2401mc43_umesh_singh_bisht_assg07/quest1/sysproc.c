#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
int sys_set_burst(void) {
    int pid, bt;
    
    // Grab the arguments
    if(argint(0, &pid) < 0 || argint(1, &bt) < 0) 
        return -1;
        
    // Call our helper function in proc.c
    return set_process_burst(pid, bt);
}
int sys_clone(void) {
    int fcn, arg, stack;
    // Unpack the 3 arguments passed from user space
    if(argint(0, &fcn) < 0 || argint(1, &arg) < 0 || argint(2, &stack) < 0) return -1;
    
    // Declare the extern kernel function from proc.c so it links properly
    extern int clone(void(*)(void*), void*, void*); 
    return clone((void(*)(void*))fcn, (void*)arg, (void*)stack);
}

int sys_join(void) {
    extern int join(void);
    return join();
}
