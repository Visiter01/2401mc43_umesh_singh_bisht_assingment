Question 1 



In the area of design and data structures, the attributes is_thread and thread_stack have been added to the struct proc in order to distinguish threads from ordinary processes. A function called clone() has been implemented which shares the calling process's address space (pgdir) but at the same time allocates a separate kernel stack and sets up the user stack to execute fcn(arg). A function named join() has been implemented in order to clean up threads that have finished running, and the exit() and wait() functions have been altered so that threads do not free the shared page table when they exit.   

Problem and Solution: In the beginning, the assignment np->parent = curproc was omitted in clone(), which caused join() to return immediately and result in the crash of the shared memory space; setting the parent pointer cured the problem.   

In threadtest.c the result was that three threads, each of which incremented a shared global counter 100,000 times, gave a final value that was less than 300,000 (approximately 135,000 to 195,000) because of the race conditions which were not synchronized.   



Question 2 



For the Design and Data Structures section, I implemented a struct semaphore (which includes an integer value and a struct spinlock called lk) in a fixed array within the kernel containing ten semaphores. The sem_init(), sem_wait(), and sem_signal() functions were created by making use of xv6's sleep() and wakeup() functions for the purpose of blocking and waking up processes.   

Problem and Solution: Since wakeup() wakes all the threads that are sleeping on a channel at the same time, there was a while(value <= 0) loop included within sem_wait() so that the threads which had been woken up would check the semaphore value again before decreasing it.   

Result (synctest.c & prodcons.c): By enclosing the counter increment within a call to sem_wait() and a call to sem_signal(), the race condition mentioned in Question 1 was eliminated and the final count obtained was exactly 300,000. The Producer-Consumer simulation, carried out on a buffer with a capacity of five slots, used empty, full, and mutex semaphores and resulted in no buffer overflow or underflow.   



Question 3 



For the Design and Data Structures I created deadlock.c in user space, using static arrays Allocation[n][m], Request[n][m], Max[n][m], Need[n][m], and Available[m]. I also implemented the function detect_deadlock() so as to simulate the release of resources and detect the processes that are deadlocked, as well as the is_safe_state() function for the purpose of deadlock avoidance using the Banker's Algorithm.   

Problem and Solution: During the live pipe deadlock test, the parent process originally carried out the detection prior to the child threads arriving at their blocking read() calls; the inclusion of a short sleep() meant that both threads ended up holding one pipe and waiting on the other before the detection took place.   

Outcome (deadlock.c):

In Test 1 (Safe Matrix) no deadlock was detected and all the processes completed in the order P0 → P2 → P3 → P1 → P4.   

In Test 2 (Deadlocked Matrix) the deadlocked processes P1, P2, P3, and P4 were correctly identified.   

In test 3 (the Banker's Algorithm) the request P1:[1,0,2] was approved and the unsafe request P0:[0,2,0] was rejected or rolled back.   

In Test 4 (Live Pipes) it was detected that there was a circular wait involving Process A (P0) and Process B (P1), the two processes holding onto and waiting for cross-connected pipes.   




Question 4 




In the area of Design and Data Structures, we added to the struct proc a priority factor (with 1 representing the highest and 20 the lowest, the default value being 10) and a wait_ticks field, together with the set_priority() and get_priority() system calls. The scheduler() function in proc.c has been modified so that it always executes the RUNNABLE process which has the lowest priority number (resolving any ties according to round-robin order), and aging has been included in trap.c to reduce the priority number by 1 each time a RUNNABLE process waits for more than 30 ticks.   

Problem & Resolution: When the parent process (which had the default priority of 10) created a child process with priority 4 or 8, it was immediately preempted; by raising the parent's priority to 1 before forking, all four of the children were able to start at the same time.   

In the program priotest.c, the four processes which were initially given priorities 4, 8, 14, and 20 completed in exactly the priority order (that is, Priority 4 then Priority 8 then Priority 14 then Priority 20), and the process with priority 20 steadily increased its priority (up to 16) and finished without being starved.
