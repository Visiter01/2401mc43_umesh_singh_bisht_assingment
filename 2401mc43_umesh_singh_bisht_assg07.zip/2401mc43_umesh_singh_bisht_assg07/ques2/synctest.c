#include "types.h"
#include "stat.h"
#include "user.h"

#define SEM_MUTEX 0

volatile int shared_counter = 0;

void
worker(void *arg)
{
  int i;
  for(i = 0; i < 100000; i++){
    sem_wait(SEM_MUTEX);
    shared_counter++;
    sem_signal(SEM_MUTEX);
  }
  exit();
}

int
main(int argc, char *argv[])
{
  void *stack1 = malloc(4096);
  void *stack2 = malloc(4096);
  void *stack3 = malloc(4096);

  sem_init(SEM_MUTEX, 1);

  printf(1, "Starting synctest with 3 threads (100,000 increments each)...\n");

  clone(worker, 0, stack1);
  clone(worker, 0, stack2);
  clone(worker, 0, stack3);

  join();
  join();
  join();

  printf(1, "Final counter value: %d (Expected: 300000)\n", shared_counter);

  free(stack1);
  free(stack2);
  free(stack3);
  exit();
}
