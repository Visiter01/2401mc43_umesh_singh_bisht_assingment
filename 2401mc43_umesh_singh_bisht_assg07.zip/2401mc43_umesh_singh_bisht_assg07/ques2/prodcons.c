#include "types.h"
#include "stat.h"
#include "user.h"

#define BUF_SIZE 5
#define TOTAL_ITEMS 15

#define SEM_MUTEX 0
#define SEM_EMPTY 1
#define SEM_FULL  2

int buffer[BUF_SIZE];
int in = 0;
int out = 0;

void
producer(void *arg)
{
  int i;
  for(i = 1; i <= TOTAL_ITEMS; i++){
    sem_wait(SEM_EMPTY); // Wait for an empty slot
    sem_wait(SEM_MUTEX); // Enter critical section

    buffer[in] = i;
    printf(1, "[Producer] Inserted item %d at buffer[%d]\n", i, in);
    in = (in + 1) % BUF_SIZE;

    sem_signal(SEM_MUTEX); // Leave critical section
    sem_signal(SEM_FULL);  // Announce a full slot

    sleep(2); // Brief pause so interleaving is clear
  }
  exit();
}

void
consumer(void *arg)
{
  int i, item;
  for(i = 1; i <= TOTAL_ITEMS; i++){
    sem_wait(SEM_FULL);  // Wait for an available item
    sem_wait(SEM_MUTEX); // Enter critical section

    item = buffer[out];
    printf(1, "  [Consumer] Removed item %d from buffer[%d]\n", item, out);
    out = (out + 1) % BUF_SIZE;

    sem_signal(SEM_MUTEX); // Leave critical section
    sem_signal(SEM_EMPTY); // Announce an empty slot

    sleep(5); // Slower consumer forces buffer to fill up and block producer!
  }
  exit();
}

int
main(int argc, char *argv[])
{
  void *pstack = malloc(4096);
  void *cstack = malloc(4096);

  sem_init(SEM_MUTEX, 1);
  sem_init(SEM_EMPTY, BUF_SIZE); // 5 empty slots initially
  sem_init(SEM_FULL, 0);         // 0 full slots initially

  printf(1, "--- Starting Producer-Consumer (Buffer Size = %d) ---\n", BUF_SIZE);

  clone(producer, 0, pstack);
  clone(consumer, 0, cstack);

  join();
  join();

  printf(1, "--- Producer-Consumer Completed Successfully ---\n");

  free(pstack);
  free(cstack);
  exit();
}
