#include "types.h"
#include "stat.h"
#include "user.h"

// Helper to find the Optimal page to replace by looking ahead in the reference string
int find_optimal(int *frames, int num_frames, char *ref_str, int current_idx) {
  int farthest_idx = -1;
  int replace_frame = -1;

  for (int i = 0; i < num_frames; i++) {
    int j;
    // Look ahead to see when this frame's page is used next
    for (j = current_idx + 1; ref_str[j] != '\0'; j++) {
      if (frames[i] == ref_str[j] - '0') {
        if (j > farthest_idx) {
          farthest_idx = j;
          replace_frame = i;
        }
        break;
      }
    }
    // If a page is never used again, it is the perfect candidate to replace
    if (ref_str[j] == '\0') {
      return i; 
    }
  }
  return replace_frame == -1 ? 0 : replace_frame;
}

// Core simulator for FIFO (0), LRU (1), and Optimal (2) algorithms
void simulate(int algo, int num_frames, char *ref_str, int verbose, int *out_f, int *out_h) {
  int frames[10];
  int tracking[10]; 
  int faults = 0, hits = 0, time = 0;
  
  for (int i = 0; i < num_frames; i++) {
    frames[i] = -1;
    tracking[i] = 0;
  }

  if (verbose) {
    char *name = algo == 0 ? "FIFO" : (algo == 1 ? "LRU" : "OPTIMAL");
    printf(1, "\n--- %s Algorithm with %d Frames ---\n", name, num_frames);
  }

  for (int i = 0; ref_str[i] != '\0'; i++) {
    int page = ref_str[i] - '0';
    int found = -1;
    time++;

    // Check for a Page Hit
    for (int j = 0; j < num_frames; j++) {
      if (frames[j] == page) {
        found = j;
        hits++;
        if (algo == 1) tracking[j] = time; // LRU updates "last used" time on hit
        break;
      }
    }

    // Handle Page Fault
    if (found == -1) {
      faults++;
      int replace_idx = -1;

      // Find an empty frame first
      for (int j = 0; j < num_frames; j++) {
        if (frames[j] == -1) {
          replace_idx = j;
          break;
        }
      }

      // If full, select victim based on algorithm[cite: 7]
      if (replace_idx == -1) {
        if (algo == 0 || algo == 1) { // FIFO or LRU[cite: 7]
          int min_time = tracking[0];
          replace_idx = 0;
          for (int j = 1; j < num_frames; j++) {
            if (tracking[j] < min_time) {
              min_time = tracking[j];
              replace_idx = j;
            }
          }
        } else if (algo == 2) { // Optimal[cite: 7]
          replace_idx = find_optimal(frames, num_frames, ref_str, i);
        }
      }

      frames[replace_idx] = page;
      if (algo == 0 || algo == 1) tracking[replace_idx] = time; 

      if (verbose) {
        printf(1, "Ref: %d -> FAULT | Frames: ", page);
        for (int j = 0; j < num_frames; j++) {
          if (frames[j] != -1) printf(1, "[%d] ", frames[j]);
          else printf(1, "[ ] ");
        }
        printf(1, "\n");
      }
    } else {
      if (verbose) {
        printf(1, "Ref: %d -> HIT   | Frames: ", page);
        for (int j = 0; j < num_frames; j++) {
          if (frames[j] != -1) printf(1, "[%d] ", frames[j]);
          else printf(1, "[ ] ");
        }
        printf(1, "\n");
      }
    }
  }

  if (out_f) *out_f = faults;
  if (out_h) *out_h = hits;

  if (verbose) {
    printf(1, "Total Page Faults: %d\n", faults);
  }
}

int main() {
  char *ref = "70120304230321201701";
  int f, h;
  
  // Task a & b: Detailed output for 3 frames across all algorithms[cite: 7]
  simulate(0, 3, ref, 1, &f, &h); // FIFO
  simulate(1, 3, ref, 1, &f, &h); // LRU
  simulate(2, 3, ref, 1, &f, &h); // Optimal
  
  // Task c: Run for 3, 4, and 5 frames to print comparison table[cite: 7]
  printf(1, "\n===========================================================================\n");
  printf(1, "                 PAGE REPLACEMENT COMPARISON TABLE\n");
  printf(1, "===========================================================================\n");
  printf(1, "Frames | Algo    | Faults | Hits | Hit Ratio (%%) | Fault Ratio (%%)\n");
  printf(1, "---------------------------------------------------------------------------\n");
  
  int frames_test[] = {3, 4, 5};
  char *names[] = {"FIFO", "LRU ", "OPT "};
  
  for(int i = 0; i < 3; i++) {
    for(int algo = 0; algo < 3; algo++) {
      simulate(algo, frames_test[i], ref, 0, &f, &h); // Run silently
      
      int total = f + h;
      int hit_r = (h * 100) / total;
      int fault_r = (f * 100) / total;
      
      printf(1, "   %d   | %s    |   %d   |  %d  |       %d%%      |       %d%%\n", 
             frames_test[i], names[algo], f, h, hit_r, fault_r);
    }
    if(i < 2) printf(1, "---------------------------------------------------------------------------\n");
  }
  printf(1, "===========================================================================\n");
  
  exit();
}
