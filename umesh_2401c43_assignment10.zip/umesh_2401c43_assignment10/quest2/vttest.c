#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, "--- Virtual to Physical Translation Test ---\n");
  
  // Allocate memory using sbrk()[cite: 7]
  char *mem = sbrk(4096); 
  mem[0] = 'X'; // Touch memory to ensure it's physically mapped
  
  // Test 1: Base address of the allocated page
  int va1 = (int)mem;
  int pa1 = vtop(va1);
  printf(1, "Valid VA: 0x%x -> PA: 0x%x\n", va1, pa1);
  
  // Test 2: Address with an offset inside the same page[cite: 7]
  int va2 = (int)(mem + 1024);
  int pa2 = vtop(va2);
  printf(1, "Valid VA: 0x%x (offset 1024) -> PA: 0x%x\n", va2, pa2);
  
  // Test 3: Demonstrate an invalid or unmapped virtual address[cite: 7]
  // We use an address far beyond the allocated heap
  int invalid_va = 0x0FFFFFFF; 
  int invalid_pa = vtop(invalid_va);
  
  if(invalid_pa == -1) {
    printf(1, "Invalid VA: 0x%x -> Result: Unmapped or Not Present (-1)\n", invalid_va);
  } else {
    printf(1, "Invalid VA: 0x%x -> PA: 0x%x (ERROR: Should be unmapped)\n", invalid_va, invalid_pa);
  }
  
  exit();
}
