#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, ">> Initial memory state:\n");
  memstats();

  printf(1, "\n>> Allocating 10 pages using sbrk(10 * 4096)...\n");
  sbrk(10 * 4096);
  
  printf(1, ">> State after allocation:\n");
  memstats();

  printf(1, "\n>> Releasing the 10 allocated pages using sbrk(-10 * 4096)...\n");
  sbrk(-10 * 4096);
  
  printf(1, ">> State after release:\n");
  memstats();

  exit();
}
