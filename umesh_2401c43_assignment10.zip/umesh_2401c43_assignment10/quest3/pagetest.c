#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, "--- Page Protection Test ---\n");
  
  // Allocate a memory page[cite: 7]
  char *mem = sbrk(4096);
  mem[0] = 'X'; // Write initially to ensure it is fully allocated in physical memory
  int va = (int)mem;

  printf(1, "\n>> Displaying page info BEFORE setting read-only:\n");
  pageinfo(va); // Display physical frame number and flags[cite: 7]

  printf(1, "\n>> Changing page to read-only...\n");
  setreadonly(va); // Remove write permission[cite: 7]

  printf(1, "\n>> Displaying page info AFTER setting read-only:\n");
  pageinfo(va);

  printf(1, "\n>> Attempting to write to the protected page (should cause a page fault!)...\n");
  mem[0] = 'Y'; // This triggers a page fault because the W flag is 0[cite: 7]

  printf(1, "ERROR: You should not see this message!\n");
  exit();
}
