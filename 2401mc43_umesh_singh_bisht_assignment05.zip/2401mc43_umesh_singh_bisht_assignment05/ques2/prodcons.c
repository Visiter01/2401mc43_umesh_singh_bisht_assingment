#include "types.h"
#include "stat.h"
#include "user.h"

#define BUF_SIZE 5

// --- LIGHTWEIGHT SEMAPHORE USING PIPES ---
// We simulate semaphores using pipes as allowed by the assignment.
// Reading from an empty pipe automatically blocks the process.

void sem_init(int fd[2], int initial_value) {
    pipe(fd);
    for(int i = 0; i < initial_value; i++) {
        write(fd[1], "x", 1); // Write a dummy byte to represent a 'token'
    }
}

void sem_wait(int fd[2]) {
    char c;
    read(fd[0], &c, 1); // Consumes a token. Blocks if 0 tokens available.
}

void sem_post(int fd[2]) {
    write(fd[1], "x", 1); // Adds a token, waking up any sleeping process.
}
// -----------------------------------------

int main() {
    int empty[2], full[2], mutex[2], data_pipe[2];
    
    // Initialize our pipe-based semaphores and lock[cite: 1]
    sem_init(empty, BUF_SIZE); // 5 empty slots initially
    sem_init(full, 0);         // 0 full slots initially
    sem_init(mutex, 1);        // Mutex lock starts at 1
    pipe(data_pipe);           // Pipe to simulate the shared buffer[cite: 1]

    printf(1, "Starting Producer-Consumer (Buffer Size: %d)\n", BUF_SIZE);

    int pid = fork();
    if(pid < 0) exit();

    if(pid > 0) { 
        // --- PRODUCER ---
        for(int i = 1; i <= 20; i++) { // Produces 1 to 20[cite: 1]
            sem_wait(empty);           // Wait for empty slot
            sem_wait(mutex);           // Lock buffer
            
            write(data_pipe[1], &i, sizeof(int)); // Insert data
            printf(1, "Producer inserted: %d\n", i);
            
            sem_post(mutex);           // Unlock buffer
            sem_post(full);            // Signal full slot
            
            sleep(2); // Short sleep[cite: 1]
        }
        wait();
    } else { 
        // --- CONSUMER ---
        for(int i = 1; i <= 20; i++) {
            sem_wait(full);            // Wait for full slot
            sem_wait(mutex);           // Lock buffer
            
            int val;
            read(data_pipe[0], &val, sizeof(int)); // Remove data
            printf(1, "Consumer removed: %d\n", val);
            
            sem_post(mutex);           // Unlock buffer
            sem_post(empty);           // Signal empty slot
            
            sleep(7); // Sleep longer to force the producer to block
        }
    }
    
    if(pid > 0) {
        printf(1, "Producer-Consumer finished successfully.\n");
    }
    exit();
}
