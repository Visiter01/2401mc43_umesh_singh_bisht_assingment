#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
int sys_set_burst(void) {
    int pid, bt;
    
    // Grab the arguments
    if(argint(0, &pid) < 0 || argint(1, &bt) < 0) 
        return -1;
        
    // Call our helper function in proc.c
    return set_process_burst(pid, bt);
}

// Global pointer to track our single shared physical page
char *shared_mem_page = 0;

int sys_shm_get(void) {
    uint va = 0x7FFFF000; // High virtual address 
    struct proc *curproc = myproc();
    
    // 1. If the page hasn't been created yet, allocate it
    if(shared_mem_page == 0) {
        shared_mem_page = kalloc();
        if(shared_mem_page == 0) {
            return -1; // Out of memory
        }
        memset(shared_mem_page, 0, PGSIZE); // Clear out garbage data
    }
    
    // 2. Map the physical page to our target virtual address
    // We declare mappages here so we can use it from vm.c
    extern int mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm);
    
    // Map with Write (PTE_W) and User (PTE_U) permissions
    if(mappages(curproc->pgdir, (void*)va, PGSIZE, V2P(shared_mem_page), PTE_W | PTE_U) < 0) {
        return -1;
    }
    
    return va; // Return the virtual address to the user program
}
