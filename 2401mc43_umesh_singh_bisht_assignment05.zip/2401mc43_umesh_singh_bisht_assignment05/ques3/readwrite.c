#include "types.h"
#include "stat.h"
#include "user.h"

struct shared_data {
    int data;
    int read_count; // Tracks active readers
    int mutex;      // Protects the read_count variable
    int wrt;        // Exclusive lock for writers (and the first/last reader)
};

// --- LIGHTWEIGHT USER-SPACE LOCKS ---
void acquire(int *lock) {
    while(*lock == 1) sleep(1); // Yield CPU to avoid harsh busy-waiting
    *lock = 1;
}

void release(int *lock) {
    *lock = 0;
}
// ------------------------------------

int main() {
    struct shared_data *shm = (struct shared_data *)shm_get();
    
    // Initialize shared variables
    shm->data = 0;
    shm->read_count = 0;
    shm->mutex = 0;
    shm->wrt = 0;
    
    printf(1, "Starting Readers-Writers (Readers Priority)\n");

    // Spawn 3 Readers
    for(int i = 1; i <= 3; i++) {
        if(fork() == 0) {
            for(int j = 0; j < 3; j++) { // Each reader reads 3 times
                sleep(2); // Stagger start times slightly
                
                // ENTRY SECTION
                acquire(&shm->mutex);
                shm->read_count++;
                // If I am the very first reader, I need to lock out the writers
                if(shm->read_count == 1) {
                    acquire(&shm->wrt);
                }
                release(&shm->mutex);
                
                // CRITICAL SECTION (Concurrent Reading allowed)
                printf(1, "Reader %d (PID %d) reading data = %d | Active readers: %d\n", i, getpid(), shm->data, shm->read_count);
                sleep(10); // Sleep inside the CS to let other readers catch up and enter concurrently
                
                // EXIT SECTION
                acquire(&shm->mutex);
                shm->read_count--;
                // If I am the very last reader, I unlock the door for writers
                if(shm->read_count == 0) {
                    release(&shm->wrt);
                }
                release(&shm->mutex);
                
                sleep(5); 
            }
            exit();
        }
    }

    // Spawn 2 Writers
    for(int i = 1; i <= 2; i++) {
        if(fork() == 0) {
            for(int j = 0; j < 3; j++) {
                sleep(5); 
                
                // ENTRY SECTION (Exclusive access required)
                acquire(&shm->wrt);
                
                // CRITICAL SECTION
                shm->data += 10;
                printf(1, "Writer %d (PID %d) exclusively writing new data = %d\n", i, getpid(), shm->data);
                sleep(10); 
                
                // EXIT SECTION
                release(&shm->wrt);
                
                sleep(5);
            }
            exit();
        }
    }

    // Parent waits for all 5 child processes (3 readers + 2 writers) to finish
    for(int i = 0; i < 5; i++) {
        wait();
    }
    
    printf(1, "All Readers and Writers finished.\n");
    exit();
}
