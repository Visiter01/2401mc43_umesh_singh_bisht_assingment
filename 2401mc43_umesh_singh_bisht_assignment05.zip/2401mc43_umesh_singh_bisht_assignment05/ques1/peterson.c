#include "types.h"
#include "stat.h"
#include "user.h"

// Define the shared memory variables
struct shared_data {
    int flag[2];
    int turn;
    int shared_counter;
};

int main() {
    struct shared_data *shm = (struct shared_data *)shm_get();
    
    if((int)shm < 0) {
        printf(1, "shm_get failed!\n");
        exit();
    }

    shm->flag[0] = 0;
    shm->flag[1] = 0;
    shm->turn = 0;
    shm->shared_counter = 0;

    int pid = fork(); // Fork one child process[cite: 1]
    if(pid < 0) exit();

    int id = (pid == 0) ? 1 : 0; 
    int other = 1 - id;          

    // Loop 10 iterations[cite: 1]
    for(int i = 0; i < 10; i++) {
        
        // Entry Section[cite: 1]
        shm->flag[id] = 1;       
        shm->turn = other;       
        
        // Busy wait[cite: 1]
        while(shm->flag[other] == 1 && shm->turn == other) {}

        // Critical Section[cite: 1]
        int temp = shm->shared_counter;
        temp++;
        sleep(1); // Force a context switch to prove mutual exclusion works
        shm->shared_counter = temp;
        
        printf(1, "Process %d in CS, counter = %d\n", id, shm->shared_counter);

        // Exit Section[cite: 1]
        shm->flag[id] = 0; 

        // Remainder Section[cite: 1]
        sleep(2); 
    }

    if(pid > 0) {
        wait();
        printf(1, "Final counter value: %d (Expected: 20)\n", shm->shared_counter);
    }
    
    exit();
}
