#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, "--- Initial Page Table ---\n");
  vmprint();
  
  printf(1, "\nCalling sbrk(4 * 4096)...\n");
  sbrk(4 * 4096);
  
  printf(1, "\n--- Page Table After sbrk ---\n");
  vmprint();
  
  exit();
}
