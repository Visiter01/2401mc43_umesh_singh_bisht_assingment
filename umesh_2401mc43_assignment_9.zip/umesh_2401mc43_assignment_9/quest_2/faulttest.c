#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
  printf(1, "Requesting 32 pages lazily...\n");
  char *mem = sbrk(32 * 4096);
  
  printf(1, "Writing to 5 distinct pages...\n");
  mem[0]          = 'A';  // Page 1
  mem[4096]       = 'B';  // Page 2
  mem[2 * 4096]   = 'C';  // Page 3
  mem[10 * 4096]  = 'D';  // Page 4
  mem[31 * 4096]  = 'E';  // Page 5
  
  int faults = getfaults();
  printf(1, "Page faults handled: %d (Expected: 5)\n", faults);
  
  printf(1, "\nAttempting to access memory out of bounds (should crash)...\n");
  mem[32 * 4096] = 'Z'; // Beyond allocated size, will trigger kill[cite: 5]
  
  printf(1, "If you see this, lazy allocation boundary check failed!\n");
  exit();
}
