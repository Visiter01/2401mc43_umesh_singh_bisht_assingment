#  xv6 Memory Management Upgrades

Hey there! Welcome to my custom modifications of the xv6 operating system.

In this project, I dove deep into the memory management subsystem of xv6 to make it smarter, lazier (in a good way!), and more transparent. If you've ever wanted to see how a kernel handles page tables or traps memory faults on the fly, you're in the right place.

##  What I Built

### 1. X-Ray Vision for Page Tables (`vmprint`)

Standard xv6 keeps its page tables hidden away in the background. I wanted to see exactly how virtual memory maps to physical hardware, so I built a new system call called `vmprint()`.

* **How it works:** When a process calls it, the kernel walks through the hardware page directory, skips the boring kernel-space stuff, and prints out every single valid user page mapping (Virtual Address ➡️ Physical Address) along with its permissions (Present, Writable, User).

* **Test it:** Run `pttest` in the shell to see a process print its memory map, allocate 4 new pages, and print the map again to prove the memory was attached!

### 2. Lazy Allocation (Because why do today what you can put off until a Page Fault?)

Originally, when a process asked xv6 for memory via `sbrk()`, the kernel went and allocated physical RAM immediately. But what if the program never actually uses that memory?

* **How it works:** I modified the kernel to be "lazy." Now, when a program asks for memory, xv6 just updates a size counter and promises the memory is there. When the program actually tries to read or write to that memory, the CPU throws a Page Fault (`T_PGFLT`). My updated trap handler catches this fault, quickly allocates a fresh page of physical RAM, maps it, and resumes the program seamlessly.

* **Test it:** Run `faulttest`. It asks for 32 pages but only writes to 5 of them. You'll see the kernel brilliantly intercept exactly 5 page faults. (It also proves the security boundaries work by intentionally crashing on an out-of-bounds access).

### 3. Page Replacement Simulator (FIFO vs. LRU)

To round out the memory theme, I built a user-space simulator to see how different algorithms handle kicking pages out of full memory frames.

* **How it works:** It feeds a specific reference string into both a First-In-First-Out (FIFO) algorithm and a Least Recently Used (LRU) algorithm.

* **Test it:** Run `pagerepl` to watch the algorithms battle it out step-by-step. You'll see that LRU is noticeably smarter, generating only 12 page faults compared to FIFO's 15 when constrained to 3 frames!

*  How to Run This Project

If you want to spin this up yourself, you'll need a standard xv6 build environment (QEMU).

1. Clone this repository and navigate to the folder.

2. Clean up any old builds:

   ```
   make clean
   
   ```

3. Boot up the xv6 operating system in QEMU:

   ```
   make qemu
   
   ```

4. Once you see the `$` prompt, you can run the test programs directly:

   * `$ pttest`

   * `$ faulttest`

   * `$ pagerepl`

##  Challenges & Learnings

The hardest part of this project was teaching xv6 not to panic! When implementing Lazy Allocation, the kernel kept crashing because the memory freeing functions (`deallocuvm` and `copyuvm`) expected every page to have physical RAM attached. I had to go into the kernel's memory tear-down logic and teach it to gracefully ignore empty, lazily-promised pages instead of throwing a `panic()`.

Thanks for checking out my work! Feel free to poke around the source code (specifically `vm.c`, `trap.c`, and `sysproc.c`) to see how the kernel magic happens.
