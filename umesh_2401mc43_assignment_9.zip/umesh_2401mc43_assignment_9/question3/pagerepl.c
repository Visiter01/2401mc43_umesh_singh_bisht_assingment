#include "types.h"
#include "stat.h"
#include "user.h"

// Simulator function to run FIFO or LRU and optionally print steps
void run_sim(int frames, char *ref_str, int is_lru, int verbose, int *out_faults, int *out_hits) {
  int frame_arr[10];
  int time_arr[10];
  int i, j;
  
  // Initialize frames as empty (-1)
  for(i = 0; i < frames; i++) {
    frame_arr[i] = -1;
    time_arr[i] = 0;
  }
  
  int faults = 0;
  int hits = 0;
  int time = 0;
  
  if (verbose) {
    printf(1, "\n--- %s Algorithm with %d Frames ---\n", is_lru ? "LRU" : "FIFO", frames);
  }
  
  for(i = 0; ref_str[i] != '\0'; i++) {
    int page = ref_str[i] - '0';
    int found = -1;
    time++;
    
    // Check if page is already in a frame (Hit)
    for(j = 0; j < frames; j++) {
      if(frame_arr[j] == page) {
        found = j;
        hits++;
        if(is_lru) time_arr[j] = time; // LRU updates time on hit
        break;
      }
    }
    
    // Page Fault
    if(found == -1) {
      faults++;
      int replace_idx = 0;
      int min_time = time_arr[0];
      
      // Find empty slot or victim frame (oldest time)
      for(j = 1; j < frames; j++) {
        if(frame_arr[j] == -1) { 
          replace_idx = j; 
          break; 
        }
        if(time_arr[j] < min_time) {
          min_time = time_arr[j];
          replace_idx = j;
        }
      }
      
      frame_arr[replace_idx] = page;
      time_arr[replace_idx] = time; // FIFO records load time, LRU records use time
      
      if (verbose) {
        printf(1, "Ref: %d -> FAULT | Frames: ", page);
        for(j = 0; j < frames; j++) {
          if(frame_arr[j] != -1) printf(1, "[%d] ", frame_arr[j]);
          else printf(1, "[ ] ");
        }
        printf(1, "\n");
      }
    } else {
      if (verbose) {
        printf(1, "Ref: %d -> HIT   | Frames: ", page);
        for(j = 0; j < frames; j++) {
          if(frame_arr[j] != -1) printf(1, "[%d] ", frame_arr[j]);
          else printf(1, "[ ] ");
        }
        printf(1, "\n");
      }
    }
  }
  
  if (out_faults) *out_faults = faults;
  if (out_hits) *out_hits = hits;
  
  if (verbose) {
    printf(1, "Summary: %d Faults, %d Hits\n", faults, hits);
  }
}

int main() {
  char *ref = "70120304230321201701";
  int f, h;
  
  // Task b: Detailed output for 3 frames (verbose = 1)
  run_sim(3, ref, 0, 1, &f, &h); // 0 = FIFO
  run_sim(3, ref, 1, 1, &f, &h); // 1 = LRU
  
  // Task c: Table for 3, 4, and 5 frames
  printf(1, "\n======================================================\n");
  printf(1, "             PAGE REPLACEMENT SUMMARY TABLE\n");
  printf(1, "======================================================\n");
  printf(1, "Frames | FIFO Faults | FIFO Hit%% | LRU Faults | LRU Hit%%\n");
  printf(1, "------------------------------------------------------\n");
  
  int frames_to_test[] = {3, 4, 5};
  for(int i = 0; i < 3; i++) {
    int frames = frames_to_test[i];
    int fifo_f, fifo_h, lru_f, lru_h;
    
    // Run silently (verbose = 0) to collect stats for the table
    run_sim(frames, ref, 0, 0, &fifo_f, &fifo_h);
    run_sim(frames, ref, 1, 0, &lru_f, &lru_h);
    
    int fifo_total = fifo_f + fifo_h;
    int fifo_ratio = (fifo_h * 100) / fifo_total;
    
    int lru_total = lru_f + lru_h;
    int lru_ratio = (lru_h * 100) / lru_total;
    
    printf(1, "   %d   |      %d      |    %d%%    |     %d     |    %d%%\n", 
           frames, fifo_f, fifo_ratio, lru_f, lru_ratio);
  }
  printf(1, "======================================================\n");
  
  exit();
}
