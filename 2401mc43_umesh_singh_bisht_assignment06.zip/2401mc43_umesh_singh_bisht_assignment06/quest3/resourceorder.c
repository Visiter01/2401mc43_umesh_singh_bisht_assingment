#include "types.h"
#include "stat.h"
#include "user.h"

// --- Real OS Locks using xv6 Pipes ---
void lock_init(int fd[2]) {
    pipe(fd);
    write(fd[1], "x", 1); // 1 token available = unlocked
}

void acquire(int fd[2]) {
    char c;
    read(fd[0], &c, 1); // Consumes token. Blocks OS process if empty!
}

void release(int fd[2]) {
    write(fd[1], "x", 1); // Returns token. Wakes up waiting process.
}
// -------------------------------------

int main(int argc, char *argv[]) {
    if(argc < 2) {
        printf(1, "Usage: resourceorder [bad|fixed]\n");
        exit();
    }

    int lock1[2], lock2[2];
    lock_init(lock1);
    lock_init(lock2);

    int is_bad = (strcmp(argv[1], "bad") == 0);

    printf(1, "--- Starting Deadlock Demonstration (%s mode) ---\n", is_bad ? "BAD" : "FIXED");

    int pidA = fork();
    if(pidA == 0) {
        // --- PROCESS A ---
        printf(1, "[Time 1] Process A: Attempting to acquire Lock1...\n");
        acquire(lock1);
        printf(1, "[Time 2] Process A: Acquired Lock1 successfully.\n");
        
        sleep(20); // Deliberate delay to ensure Process B gets CPU time
        
        printf(1, "[Time 5] Process A: Attempting to acquire Lock2...\n");
        acquire(lock2); // Will hang here in 'bad' mode
        printf(1, "[Time 6] Process A: Acquired Lock2 successfully.\n");
        
        release(lock2);
        release(lock1);
        printf(1, "Process A: Finished and released locks.\n");
        exit();
    }

    int pidB = fork();
    if(pidB == 0) {
        // --- PROCESS B ---
        sleep(5); // Slight offset so A goes first
        
        if(is_bad) {
            // DEADLOCK MODE: Inconsistent ordering (Requests Lock2 then Lock1)
            printf(1, "[Time 3] Process B: Attempting to acquire Lock2...\n");
            acquire(lock2);
            printf(1, "[Time 4] Process B: Acquired Lock2 successfully.\n");
            
            sleep(20); 
            
            printf(1, "[Time 7] Process B: Attempting to acquire Lock1...\n");
            acquire(lock1); // DEADLOCK!
            printf(1, "[Time 8] Process B: Acquired Lock1 successfully.\n");
            
            release(lock1);
            release(lock2);
        } else {
            // FIXED MODE: Consistent ordering (Requests Lock1 then Lock2)
            printf(1, "[Time 3] Process B: Attempting to acquire Lock1...\n");
            acquire(lock1); // Blocks safely while A holds Lock1
            printf(1, "[Time 4] Process B: Acquired Lock1 successfully.\n");
            
            sleep(20);
            
            printf(1, "[Time 7] Process B: Attempting to acquire Lock2...\n");
            acquire(lock2);
            printf(1, "[Time 8] Process B: Acquired Lock2 successfully.\n");
            
            release(lock2);
            release(lock1);
        }
        
        printf(1, "Process B: Finished and released locks.\n");
        exit();
    }

    // Parent waits for children
    wait();
    wait();
    
    printf(1, "--- Execution Complete. No Deadlock! ---\n");
    exit();
}
