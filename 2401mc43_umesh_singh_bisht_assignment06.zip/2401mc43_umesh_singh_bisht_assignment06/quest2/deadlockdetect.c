#include "types.h"
#include "stat.h"
#include "user.h"

#define MAX_N 10 // Max processes
#define MAX_M 10 // Max resources

int WFG[MAX_N][MAX_N]; // Wait-For Graph adjacency matrix
int visited[MAX_N];    // 0 = unvisited, 1 = visiting, 2 = fully visited
int parent[MAX_N];     // To reconstruct the exact cycle path
int N_proc;

// --- DFS Cycle Detection Algorithm ---
int dfs(int u) {
    visited[u] = 1; // Mark as currently in the recursion stack
    
    for(int v = 0; v < N_proc; v++) {
        if(WFG[u][v] == 1) { // If edge u -> v exists
            if(visited[v] == 0) { 
                parent[v] = u;
                if(dfs(v)) return 1;
            } else if(visited[v] == 1) { 
                // Back-edge found! We hit a node already in our stack.
                // Reconstruct the cycle backward using the parent array
                int curr = u;
                int cycle[MAX_N];
                int count = 0;
                
                cycle[count++] = v;
                while(curr != v) {
                    cycle[count++] = curr;
                    curr = parent[curr];
                }
                cycle[count++] = v;
                
                // Print the cycle in forward order
                printf(1, "Result: DEADLOCK DETECTED!\nCycle: ");
                for(int i = count - 1; i >= 0; i--) {
                    printf(1, "P%d", cycle[i]);
                    if(i > 0) printf(1, " -> ");
                }
                printf(1, "\n");
                return 1;
            }
        }
    }
    
    visited[u] = 2; // Mark as fully visited
    return 0;
}

// --- Graph Construction and Detection Setup ---
void detect_deadlock(int n, int m, int alloc[MAX_N][MAX_M], int req[MAX_N][MAX_M]) {
    N_proc = n;
    
    // 1. Initialize Graph and tracking arrays
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            WFG[i][j] = 0;
        }
        visited[i] = 0;
        parent[i] = -1;
    }
    
    // 2. Build the Wait-For Graph
    for(int i = 0; i < n; i++) {
        for(int r = 0; r < m; r++) {
            if(req[i][r] == 1) {
                // Process i is requesting resource r. Who holds it?
                for(int j = 0; j < n; j++) {
                    if(alloc[j][r] == 1 && i != j) {
                        WFG[i][j] = 1; // Add directed edge Pi -> Pj
                    }
                }
            }
        }
    }
    
    // 3. Print the edges to prove it works
    printf(1, "Wait-For Graph Edges:\n");
    int edges = 0;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(WFG[i][j]) {
                printf(1, "  P%d -> P%d\n", i, j);
                edges++;
            }
        }
    }
    if(edges == 0) printf(1, "  (No edges)\n");
    
    // 4. Run DFS Cycle Detection on all unvisited nodes
    int has_deadlock = 0;
    for(int i = 0; i < n; i++) {
        if(visited[i] == 0) {
            if(dfs(i)) {
                has_deadlock = 1;
                break;
            }
        }
    }
    
    if(!has_deadlock) {
        printf(1, "Result: No deadlock detected. System is safe.\n");
    }
}

int main() {
    // --- SCENARIO 1: No Deadlock ---
    // Acyclic wait: P0 waits for P1, P2 waits for P0. P1 can finish.
    printf(1, "--- Scenario 1: Acyclic Wait (No Deadlock) ---\n");
    int n1 = 3, m1 = 3;
    int alloc1[MAX_N][MAX_M] = {0};
    int req1[MAX_N][MAX_M] = {0};
    
    alloc1[0][0] = 1; // P0 holds R0
    alloc1[1][1] = 1; // P1 holds R1
    alloc1[2][2] = 1; // P2 holds R2
    
    req1[0][1] = 1;   // P0 wants R1 (held by P1)
    req1[2][0] = 1;   // P2 wants R0 (held by P0)
    
    detect_deadlock(n1, m1, alloc1, req1);
    
    printf(1, "\n----------------------------------------\n\n");
    
    // --- SCENARIO 2: Deadlock with 4-Process Circular Wait ---
    // This perfectly satisfies the "3 or more processes" requirement.
    printf(1, "--- Scenario 2: 4-Process Circular Wait (Deadlock) ---\n");
    int n2 = 4, m2 = 4;
    int alloc2[MAX_N][MAX_M] = {0};
    int req2[MAX_N][MAX_M] = {0};
    
    alloc2[0][0] = 1; // P0 holds R0
    alloc2[1][1] = 1; // P1 holds R1
    alloc2[2][2] = 1; // P2 holds R2
    alloc2[3][3] = 1; // P3 holds R3
    
    // Circular Request loop!
    req2[0][1] = 1; // P0 wants R1 (held by P1)
    req2[1][2] = 1; // P1 wants R2 (held by P2)
    req2[2][3] = 1; // P2 wants R3 (held by P3)
    req2[3][0] = 1; // P3 wants R0 (held by P0)
    
    detect_deadlock(n2, m2, alloc2, req2);
    
    exit();
}
