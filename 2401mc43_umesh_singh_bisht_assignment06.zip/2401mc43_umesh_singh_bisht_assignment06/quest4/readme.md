Deadlock Prevention Strategy Used: Hierarchical Resource Ordering

For Question 4, I implemented Resource Ordering to prevent deadlocks. The system has three resource types: Scanners (1), Printers (2), and Disks (2). To ensure the system never enters a deadlocked state, I established a strict global hierarchy: Scanner (Priority 1) -> Printer (Priority 2) -> Disk (Priority 3).

Every process is hardcoded to request its required resources in this exact sequence. Because all processes request resources in the same "direction," the Coffman condition of Circular Wait is mathematically impossible to achieve. A process holding a Disk will never attempt to acquire a Scanner, thereby guaranteeing that the wait-for graph remains acyclic and the system runs all cycles without freezing.
