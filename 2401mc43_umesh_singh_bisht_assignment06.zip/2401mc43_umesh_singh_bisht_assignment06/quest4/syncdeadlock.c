#include "types.h"
#include "stat.h"
#include "user.h"

// --- Pipe-Based Counting Semaphores ---
void sem_init(int fd[2], int initial_value) {
    pipe(fd);
    for(int i = 0; i < initial_value; i++) {
        write(fd[1], "x", 1);
    }
}

void sem_wait(int fd[2]) {
    char c;
    read(fd[0], &c, 1); // Blocks OS process if 0 tokens available
}

void sem_post(int fd[2]) {
    write(fd[1], "x", 1); // Adds a token back
}
// --------------------------------------

// Generic worker function for the processes
void worker(int pid, char* res1_name, int res1_fd[2], char* res2_name, int res2_fd[2]) {
    for(int iter = 1; iter <= 2; iter++) { // 2 cycles to prove it doesn't hang
        printf(1, "[Cycle %d] P%d requesting %s...\n", iter, pid, res1_name);
        sem_wait(res1_fd);
        printf(1, "[Cycle %d] P%d GRANTED %s.\n", iter, pid, res1_name);
        
        sleep(2); // Slight delay to encourage interleaving
        
        printf(1, "[Cycle %d] P%d requesting %s...\n", iter, pid, res2_name);
        sem_wait(res2_fd);
        printf(1, "[Cycle %d] P%d GRANTED %s.\n", iter, pid, res2_name);
        
        // Both resources acquired - Critical Section
        printf(1, ">>> P%d WORKING with %s and %s...\n", pid, res1_name, res2_name);
        sleep(10); // Simulate actual work
        
        // Release resources (reverse order is standard practice)
        sem_post(res2_fd);
        printf(1, "[Cycle %d] P%d released %s.\n", iter, pid, res2_name);
        
        sem_post(res1_fd);
        printf(1, "[Cycle %d] P%d released %s.\n", iter, pid, res1_name);
        
        sleep(5); // Rest before next cycle
    }
    printf(1, "--- P%d FINISHED all work! ---\n", pid);
    exit();
}

int main() {
    int scanner[2]; // 1 instance
    int printer[2]; // 2 instances
    int disk[2];    // 2 instances
    
    // Initialize Resource Pools
    sem_init(scanner, 1);
    sem_init(printer, 2);
    sem_init(disk, 2);
    
    printf(1, "Starting Combined Sync & Deadlock Avoidance...\n");
    printf(1, "Global Resource Order: SCANNER -> PRINTER -> DISK\n\n");

    // Spawn 5 Processes
    // Notice how every single process requests resources following the global order!
    for(int i = 0; i < 5; i++) {
        if(fork() == 0) {
            if(i == 0) {
                worker(0, "Scanner", scanner, "Printer", printer);
            } else if(i == 1) {
                worker(1, "Printer", printer, "Disk", disk);
            } else if(i == 2) {
                worker(2, "Scanner", scanner, "Disk", disk);
            } else if(i == 3) {
                worker(3, "Printer", printer, "Disk", disk);
            } else if(i == 4) {
                worker(4, "Scanner", scanner, "Printer", printer);
            }
        }
    }

    // Parent waits for all 5 children to finish
    for(int i = 0; i < 5; i++) {
        wait();
    }
    
    printf(1, "\nAll processes completed successfully. No deadlocks!\n");
    exit();
}
