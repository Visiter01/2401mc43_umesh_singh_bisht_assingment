#include "types.h"
#include "stat.h"
#include "user.h"

#define N 5 // Number of processes
#define M 3 // Number of resource types

// Classic textbook scenario hardcoded
int Allocation[N][M] = {
    {0, 1, 0}, // P0
    {2, 0, 0}, // P1
    {3, 0, 2}, // P2
    {2, 1, 1}, // P3
    {0, 0, 2}  // P4
};

int Max[N][M] = {
    {7, 5, 3}, // P0
    {3, 2, 2}, // P1
    {9, 0, 2}, // P2
    {2, 2, 2}, // P3
    {4, 3, 3}  // P4
};

int Available[M] = {3, 3, 2}; // A, B, C
int Need[N][M];

// --- Compute the Need Matrix ---
void compute_need() {
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < M; j++) {
            Need[i][j] = Max[i][j] - Allocation[i][j];
        }
    }
}

// --- Safety Algorithm ---
// Returns 1 if safe, 0 if unsafe. Prints the sequence if safe.
int check_safe() {
    int Work[M];
    int Finish[N];
    int safe_seq[N];
    int count = 0;

    for(int i = 0; i < M; i++) Work[i] = Available[i];
    for(int i = 0; i < N; i++) Finish[i] = 0;

    while(count < N) {
        int found = 0;
        for(int p = 0; p < N; p++) {
            if(Finish[p] == 0) {
                int can_finish = 1;
                for(int j = 0; j < M; j++) {
                    if(Need[p][j] > Work[j]) {
                        can_finish = 0;
                        break;
                    }
                }
                if(can_finish) {
                    for(int j = 0; j < M; j++) {
                        Work[j] += Allocation[p][j];
                    }
                    safe_seq[count++] = p;
                    Finish[p] = 1;
                    found = 1;
                }
            }
        }
        if(found == 0) {
            return 0; // Unsafe state detected
        }
    }
    
    printf(1, "System is in a SAFE state.\nSafe sequence: ");
    for(int i = 0; i < N; i++) {
        printf(1, "P%d ", safe_seq[i]);
    }
    printf(1, "\n");
    return 1;
}

// --- Resource Request Algorithm ---
void request_resources(int pid, int req[]) {
    printf(1, "\n--- Process P%d requesting resources: %d %d %d ---\n", pid, req[0], req[1], req[2]);
    
    // Step 1: Check if request exceeds Need
    for(int j = 0; j < M; j++) {
        if(req[j] > Need[pid][j]) {
            printf(1, "Error: Process has exceeded its maximum claim.\n");
            return;
        }
    }

    // Step 2: Check if request exceeds Available
    for(int j = 0; j < M; j++) {
        if(req[j] > Available[j]) {
            printf(1, "Request denied: Process P%d must wait, resources not available.\n", pid);
            return;
        }
    }

    // Step 3: Simulate granting the request
    for(int j = 0; j < M; j++) {
        Available[j] -= req[j];
        Allocation[pid][j] += req[j];
        Need[pid][j] -= req[j];
    }

    // Step 4: Check if the new state is safe
    if(check_safe()) {
        printf(1, "Request granted successfully.\n");
    } else {
        printf(1, "Request denied — would lead to unsafe state. Rolling back.\n");
        // Rollback to original state
        for(int j = 0; j < M; j++) {
            Available[j] += req[j];
            Allocation[pid][j] -= req[j];
            Need[pid][j] += req[j];
        }
    }
}

int main() {
    printf(1, "--- Banker's Algorithm Initialization ---\n");
    compute_need();
    
    printf(1, "\nInitial State Assessment:\n");
    check_safe();

    // Scenario 1: A request that will be GRANTED safely
    // P1 requests (1, 0, 2)
    int req1[] = {1, 0, 2};
    request_resources(1, req1);

    // Scenario 2: A request that will be DENIED to prevent deadlock
    // P0 requests (0, 2, 0). (Available is 2, 3, 0 now, so it has enough, but granting it causes deadlock!)
    int req2[] = {0, 2, 0}; 
    request_resources(0, req2);
    
    exit();
}
